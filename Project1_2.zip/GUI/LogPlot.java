public class LogPlot {
}
